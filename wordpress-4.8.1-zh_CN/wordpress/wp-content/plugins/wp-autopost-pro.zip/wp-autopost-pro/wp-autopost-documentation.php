<div class="wrap">
 <div class="icon32" id="icon-wp-autopost"><br/></div>
 <h2>Auto Post</h2>
 <br/>
 <?php if(get_bloginfo('language')=='zh-CN'||get_bloginfo('language')=='zh-TW'): ?> 
  <h2><i><a href="http://wp-autopost.org/zh/documentation/" target="_blank"><?php  _e('Documentation','wp-autopost'); ?></a></i></h2>
 <?php else: ?>
  <h2><i><a href="http://wp-autopost.org/documentation/" target="_blank"><?php  _e('Documentation','wp-autopost'); ?></a></i></h2>
 <?php endif; ?>
</div>