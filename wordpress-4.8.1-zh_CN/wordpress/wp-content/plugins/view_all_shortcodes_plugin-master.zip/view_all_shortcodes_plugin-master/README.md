A Wordpress plugin that allows you to see all the available shortcodes on your blog.

The reason why this isn't hosted on the Wordpress repository is because it is a very small plugin which can be done with a line of code so I don't see the need to put this on the repository.